# `TROC-MONDE`


### `USE-CASES`
    1 - Consuler la liste des biens et services existants
    2 - Troquer un produit
    3 - Faire  le CRUD (Admin)
    

### `DESCRIPTION-TEXTUELLES`

#### CONSULTER LA LISTE DES BIENS ET SERVICES EXISTANTS

    1 - L'utilisateur accede à la plate 
    2 - Le système afficher une liste de produits en cour pour etre troquer
    3 - L'utilisateur fait eventuellement une rechercher pour trier les produits disponibles


#### TROQUER UN PRODUIT

    1 - Consulter la liste des biens et services existants
    2 - Choisir un produit parmi ceux existant 
    3 - Acceder aux informations completes du produit
        
        * Nom produit 
        * Caracteristique 
        * Valeur 
        * Liste des propositions de troc en vue(en cours ou refusé) concercant le produit.
        * Ajuster (on click)
        * Formulaire à remplir
            * Le nom du produit 
            * Caracteristique 
            * Valeur 
            * Image
            * Adresse
            * Contact 
            * Afficher contact intermediare.
            * 
        * Soumettre
        * Update les informations
   






#### FAIRE  LE CRUD (Admin)
    1 - Se Connecter en tant qu'administrateur 
    2 - Rechercher la negatiatoin d'id = "something"
    3 - Supprimer toutes les postes concernant la négociation 