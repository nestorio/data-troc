# Plateforme de troc
