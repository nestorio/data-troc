from flask import Flask, render_template, url_for, request, session, redirect, Markup, flash

def apropos():
    return "No template yet"